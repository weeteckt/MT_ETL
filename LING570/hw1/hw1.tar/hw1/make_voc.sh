#!/bin/sh

./make_voc.pl $@
