#!/bin/sh

./eng_tokenizer.pl $@
