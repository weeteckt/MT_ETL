#!/bin/sh

./ppl.pl $@ > $6