#!/bin/sh

./ngram_count.pl < $1 > $2