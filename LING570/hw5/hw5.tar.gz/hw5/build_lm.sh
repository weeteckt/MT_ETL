#!/bin/sh

./build_lm.pl < $1 > $2