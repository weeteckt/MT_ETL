#!/bin/sh

./trainer.pl < $1 > $2
