#!/bin/sh

./expand_fsm1.pl $1 $2 > $3