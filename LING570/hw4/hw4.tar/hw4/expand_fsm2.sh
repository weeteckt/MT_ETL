#!/bin/sh

./expand_fsm2.pl $1 $2 > $3