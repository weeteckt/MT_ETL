#!/bin/sh

./proc_input.pl $@