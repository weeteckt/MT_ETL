#!/bin/sh

./viterbi.pl $@ > $3