#!/bin/sh

./create_3gram_hmm.pl $@ > $1