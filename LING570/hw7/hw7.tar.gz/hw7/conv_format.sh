#!/bin/sh

./conv_format.pl $@ 