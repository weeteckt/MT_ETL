#!/bin/sh

./proc_file.pl $@ > $3