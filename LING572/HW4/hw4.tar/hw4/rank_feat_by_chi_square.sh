#!/bin/sh


perl rank_feat_by_chi_square.pl $@