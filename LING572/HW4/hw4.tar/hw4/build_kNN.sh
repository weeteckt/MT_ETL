#!/bin/sh


perl build_kNN.pl $@