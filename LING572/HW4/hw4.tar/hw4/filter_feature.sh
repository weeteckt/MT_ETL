#!/bin/sh


perl filter_feature.pl $@