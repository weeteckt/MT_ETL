#!/bin/sh


perl TBL_train.pl $@