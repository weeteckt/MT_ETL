#!/bin/sh


perl TBL_classify.pl $@