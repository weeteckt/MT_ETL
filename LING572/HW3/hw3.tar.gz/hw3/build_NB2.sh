#!/bin/sh


perl build_NB2.pl $@