#!/bin/sh


perl build_NB1.pl $@