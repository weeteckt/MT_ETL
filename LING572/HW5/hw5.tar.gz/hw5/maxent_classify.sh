#!/bin/sh


perl maxent_classify.pl $@