#!/bin/sh


perl calc_emp_exp.pl $@