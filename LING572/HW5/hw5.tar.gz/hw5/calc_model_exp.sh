#!/bin/sh


perl calc_model_exp.pl $@